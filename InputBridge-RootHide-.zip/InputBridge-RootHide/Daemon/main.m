#import <Foundation/Foundation.h>

static NSString * const IBStatePath = @"/tmp/inputbridge-daemon.log";

int main(int argc, char *argv[]) {
	@autoreleasepool {
		NSString *line = [NSString stringWithFormat:
			@"[%@] inputbridged started. This helper is diagnostic only; it does not inject input into other apps.\n",
			NSDate.date];
		[line writeToFile:IBStatePath atomically:YES encoding:NSUTF8StringEncoding error:nil];

		[[NSRunLoop currentRunLoop] run];
	}
	return 0;
}
