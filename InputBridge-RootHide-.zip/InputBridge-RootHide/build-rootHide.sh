#!/bin/sh
set -e
export THEOS_PACKAGE_SCHEME=roothide
make clean
make package
echo "Built packages:"
ls -lah packages/*.deb
