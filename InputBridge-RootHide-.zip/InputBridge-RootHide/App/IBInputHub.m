#import "IBInputHub.h"
#import <GameController/GameController.h>

@interface IBInputHub ()
@property (nonatomic, assign, readwrite) BOOL keyboardConnected;
@property (nonatomic, assign, readwrite) BOOL mouseConnected;
@property (nonatomic, assign, readwrite) double mouseDX;
@property (nonatomic, assign, readwrite) double mouseDY;
@property (nonatomic, assign, readwrite) BOOL leftDown;
@property (nonatomic, assign, readwrite) BOOL rightDown;
@property (nonatomic, strong) NSMutableSet<NSString *> *mutableKeys;
@property (nonatomic, strong) NSMutableArray<NSString *> *mutableLog;
@end

@implementation IBInputHub

- (instancetype)init {
	self = [super init];
	if (self) {
		_mutableKeys = [NSMutableSet set];
		_mutableLog = [NSMutableArray array];

		NSNotificationCenter *c = NSNotificationCenter.defaultCenter;
		[c addObserver:self selector:@selector(keyboardConnectedNote:) name:GCKeyboardDidConnectNotification object:nil];
		[c addObserver:self selector:@selector(keyboardDisconnectedNote:) name:GCKeyboardDidDisconnectNotification object:nil];
		[c addObserver:self selector:@selector(mouseConnectedNote:) name:GCMouseDidConnectNotification object:nil];
		[c addObserver:self selector:@selector(mouseDisconnectedNote:) name:GCMouseDidDisconnectNotification object:nil];

		if (GCKeyboard.coalescedKeyboard) {
			[self attachKeyboard:GCKeyboard.coalescedKeyboard];
		}
		if (GCMouse.current) {
			[self attachMouse:GCMouse.current];
		}
	}
	return self;
}

- (void)dealloc {
	[NSNotificationCenter.defaultCenter removeObserver:self];
}

- (NSArray<NSString *> *)pressedKeys {
	return [self.mutableKeys.allObjects sortedArrayUsingSelector:@selector(compare:)];
}

- (NSArray<NSString *> *)eventLog {
	return self.mutableLog.copy;
}

- (BOOL)isKeyDown:(NSString *)key {
	return [self.mutableKeys containsObject:key.uppercaseString];
}

- (void)keyboardConnectedNote:(NSNotification *)note {
	if ([note.object isKindOfClass:GCKeyboard.class]) {
		[self attachKeyboard:(GCKeyboard *)note.object];
	}
}

- (void)keyboardDisconnectedNote:(NSNotification *)note {
	self.keyboardConnected = NO;
	[self.mutableKeys removeAllObjects];
	[self emit];
}

- (void)mouseConnectedNote:(NSNotification *)note {
	if ([note.object isKindOfClass:GCMouse.class]) {
		[self attachMouse:(GCMouse *)note.object];
	}
}

- (void)mouseDisconnectedNote:(NSNotification *)note {
	self.mouseConnected = NO;
	self.leftDown = NO;
	self.rightDown = NO;
	[self emit];
}

- (void)attachKeyboard:(GCKeyboard *)keyboard API_AVAILABLE(ios(14.0)) {
	self.keyboardConnected = YES;
	GCKeyboardInput *input = keyboard.keyboardInput;
	if (!input) return;

	__weak typeof(self) weakSelf = self;
	input.keyChangedHandler = ^(GCKeyboardInput *keyboardInput, GCControllerButtonInput *key, GCKeyCode keyCode, BOOL pressed) {
		dispatch_async(dispatch_get_main_queue(), ^{
			__strong typeof(weakSelf) self = weakSelf;
			if (!self) return;
			NSString *name = [self keyName:keyCode];
			if (pressed) [self.mutableKeys addObject:name];
			else [self.mutableKeys removeObject:name];
			[self pushLog:[NSString stringWithFormat:@"KEY %@ %@", name, pressed ? @"DOWN" : @"UP"]];
			[self emit];
		});
	};
	[self emit];
}

- (void)attachMouse:(GCMouse *)mouse API_AVAILABLE(ios(14.0)) {
	self.mouseConnected = YES;
	GCMouseInput *input = mouse.mouseInput;
	if (!input) return;

	__weak typeof(self) weakSelf = self;
	input.mouseMovedHandler = ^(GCMouseInput *mouseInput, float deltaX, float deltaY) {
		dispatch_async(dispatch_get_main_queue(), ^{
			__strong typeof(weakSelf) self = weakSelf;
			if (!self) return;
			self.mouseDX = deltaX;
			self.mouseDY = deltaY;
			[self pushLog:[NSString stringWithFormat:@"MOUSE dx %.2f dy %.2f", deltaX, deltaY]];
			[self emit];
		});
	};

	input.leftButton.pressedChangedHandler = ^(GCControllerButtonInput *button, float value, BOOL pressed) {
		dispatch_async(dispatch_get_main_queue(), ^{
			__strong typeof(weakSelf) self = weakSelf;
			if (!self) return;
			self.leftDown = pressed;
			[self pushLog:[NSString stringWithFormat:@"MOUSE LEFT %@", pressed ? @"DOWN" : @"UP"]];
			[self emit];
		});
	};

	if (input.rightButton) {
		input.rightButton.pressedChangedHandler = ^(GCControllerButtonInput *button, float value, BOOL pressed) {
			dispatch_async(dispatch_get_main_queue(), ^{
				__strong typeof(weakSelf) self = weakSelf;
				if (!self) return;
				self.rightDown = pressed;
				[self pushLog:[NSString stringWithFormat:@"MOUSE RIGHT %@", pressed ? @"DOWN" : @"UP"]];
				[self emit];
			});
		};
	}
	[self emit];
}

- (void)pushLog:(NSString *)line {
	NSString *timestamp = [NSDateFormatter localizedStringFromDate:NSDate.date
														 dateStyle:NSDateFormatterNoStyle
														 timeStyle:NSDateFormatterMediumStyle];
	[self.mutableLog insertObject:[NSString stringWithFormat:@"%@  %@", timestamp, line] atIndex:0];
	if (self.mutableLog.count > 200) {
		[self.mutableLog removeObjectsInRange:NSMakeRange(200, self.mutableLog.count - 200)];
	}
}

- (void)clearLog {
	[self.mutableLog removeAllObjects];
	[self emit];
}

- (void)emit {
	if (self.onUpdate) self.onUpdate();
}

- (NSString *)keyName:(GCKeyCode)code {
	// GCKeyCode values are exported constants, not compile-time enum cases,
	// so compare them with if-statements instead of using switch/case.
	if (code == GCKeyCodeKeyA) return @"A";
	if (code == GCKeyCodeKeyB) return @"B";
	if (code == GCKeyCodeKeyC) return @"C";
	if (code == GCKeyCodeKeyD) return @"D";
	if (code == GCKeyCodeKeyE) return @"E";
	if (code == GCKeyCodeKeyF) return @"F";
	if (code == GCKeyCodeKeyG) return @"G";
	if (code == GCKeyCodeKeyH) return @"H";
	if (code == GCKeyCodeKeyI) return @"I";
	if (code == GCKeyCodeKeyJ) return @"J";
	if (code == GCKeyCodeKeyK) return @"K";
	if (code == GCKeyCodeKeyL) return @"L";
	if (code == GCKeyCodeKeyM) return @"M";
	if (code == GCKeyCodeKeyN) return @"N";
	if (code == GCKeyCodeKeyO) return @"O";
	if (code == GCKeyCodeKeyP) return @"P";
	if (code == GCKeyCodeKeyQ) return @"Q";
	if (code == GCKeyCodeKeyR) return @"R";
	if (code == GCKeyCodeKeyS) return @"S";
	if (code == GCKeyCodeKeyT) return @"T";
	if (code == GCKeyCodeKeyU) return @"U";
	if (code == GCKeyCodeKeyV) return @"V";
	if (code == GCKeyCodeKeyW) return @"W";
	if (code == GCKeyCodeKeyX) return @"X";
	if (code == GCKeyCodeKeyY) return @"Y";
	if (code == GCKeyCodeKeyZ) return @"Z";
	if (code == GCKeyCodeSpacebar) return @"SPACE";
	if (code == GCKeyCodeReturnOrEnter) return @"ENTER";
	if (code == GCKeyCodeEscape) return @"ESC";
	return [NSString stringWithFormat:@"KEY_%ld", (long)code];
}

@end
