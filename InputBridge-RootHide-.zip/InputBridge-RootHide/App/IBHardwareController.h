#import <UIKit/UIKit.h>

@interface IBHardwareController : UITableViewController
@end
