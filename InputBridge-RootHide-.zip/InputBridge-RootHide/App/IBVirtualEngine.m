#import "IBVirtualEngine.h"
#import "IBInputHub.h"

@implementation IBVirtualEngine

- (instancetype)init {
	self = [super init];
	if (self) {
		_moveTouch = CGPointMake(0.25, 0.70);
		_aimTouch = CGPointMake(0.78, 0.70);
		_sensitivityX = 1.0;
		_sensitivityY = 1.0;
	}
	return self;
}

static double IBClamp(double value, double low, double high) {
	return MIN(MAX(value, low), high);
}

- (void)updateFromInput:(IBInputHub *)input {
	double x = 0.0;
	double y = 0.0;
	if ([input isKeyDown:@"A"]) x -= 1.0;
	if ([input isKeyDown:@"D"]) x += 1.0;
	if ([input isKeyDown:@"W"]) y -= 1.0;
	if ([input isKeyDown:@"S"]) y += 1.0;

	self.leftStickX = x;
	self.leftStickY = -y;
	self.moveTouchDown = (x != 0.0 || y != 0.0);
	self.moveTouch = CGPointMake(
		IBClamp(0.25 + x * 0.08, 0.05, 0.95),
		IBClamp(0.70 + y * 0.08, 0.05, 0.95)
	);

	self.aimTouch = CGPointMake(
		IBClamp(self.aimTouch.x + input.mouseDX * 0.0006 * self.sensitivityX, 0.05, 0.95),
		IBClamp(self.aimTouch.y + input.mouseDY * 0.0006 * self.sensitivityY, 0.05, 0.95)
	);
	self.aimTouchDown = input.leftDown;
	self.rightStickX = IBClamp(input.mouseDX * 0.02 * self.sensitivityX, -1.0, 1.0);
	self.rightStickY = IBClamp(-input.mouseDY * 0.02 * self.sensitivityY, -1.0, 1.0);
}

@end
