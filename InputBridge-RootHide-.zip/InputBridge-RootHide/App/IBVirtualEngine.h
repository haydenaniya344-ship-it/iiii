#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

@class IBInputHub;

NS_ASSUME_NONNULL_BEGIN

@interface IBVirtualEngine : NSObject
@property (nonatomic, assign) CGPoint moveTouch;
@property (nonatomic, assign) CGPoint aimTouch;
@property (nonatomic, assign) BOOL moveTouchDown;
@property (nonatomic, assign) BOOL aimTouchDown;
@property (nonatomic, assign) double leftStickX;
@property (nonatomic, assign) double leftStickY;
@property (nonatomic, assign) double rightStickX;
@property (nonatomic, assign) double rightStickY;
@property (nonatomic, assign) double sensitivityX;
@property (nonatomic, assign) double sensitivityY;

- (void)updateFromInput:(IBInputHub *)input;
@end

NS_ASSUME_NONNULL_END
