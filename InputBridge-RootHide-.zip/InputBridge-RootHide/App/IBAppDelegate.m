#import "IBAppDelegate.h"
#import "IBRootController.h"

@implementation IBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
	IBRootController *root = [[IBRootController alloc] init];
	self.window.rootViewController = root;
	[self.window makeKeyAndVisible];
	return YES;
}

@end
