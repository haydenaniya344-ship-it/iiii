#import "IBRootController.h"
#import "IBInputHub.h"
#import "IBVirtualEngine.h"
#import "IBHardwareController.h"

@interface IBStatusController : UIViewController
@property (nonatomic, strong) IBInputHub *input;
@property (nonatomic, strong) IBVirtualEngine *engine;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UILabel *virtualLabel;
@property (nonatomic, strong) UIView *touchCanvas;
@property (nonatomic, strong) UIView *moveDot;
@property (nonatomic, strong) UIView *aimDot;
@end

@interface IBLogController : UITableViewController
@property (nonatomic, strong) IBInputHub *input;
@end

@implementation IBRootController

- (void)viewDidLoad {
	[super viewDidLoad];

	IBInputHub *input = [[IBInputHub alloc] init];
	IBVirtualEngine *engine = [[IBVirtualEngine alloc] init];

	IBStatusController *status = [[IBStatusController alloc] init];
	status.input = input;
	status.engine = engine;
	status.title = [self zh] ? @"总览" : @"Dashboard";
	UINavigationController *n1 = [[UINavigationController alloc] initWithRootViewController:status];
	n1.tabBarItem = [[UITabBarItem alloc] initWithTitle:status.title image:[UIImage systemImageNamed:@"dot.radiowaves.left.and.right"] tag:0];

	IBLogController *log = [[IBLogController alloc] initWithStyle:UITableViewStyleInsetGrouped];
	log.input = input;
	log.title = [self zh] ? @"输入" : @"Input";
	UINavigationController *n2 = [[UINavigationController alloc] initWithRootViewController:log];
	n2.tabBarItem = [[UITabBarItem alloc] initWithTitle:log.title image:[UIImage systemImageNamed:@"waveform.path.ecg"] tag:1];

	IBHardwareController *hardware = [[IBHardwareController alloc] initWithStyle:UITableViewStyleInsetGrouped];
	UINavigationController *n3 = [[UINavigationController alloc] initWithRootViewController:hardware];
	n3.tabBarItem = [[UITabBarItem alloc] initWithTitle:hardware.title image:[UIImage systemImageNamed:@"externaldrive.connected.to.line.below"] tag:2];

	self.viewControllers = @[n1, n2, n3];
}

- (BOOL)zh {
	return [[[NSLocale preferredLanguages] firstObject] hasPrefix:@"zh"];
}

@end

@implementation IBStatusController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.view.backgroundColor = UIColor.systemBackgroundColor;

	self.statusLabel = [[UILabel alloc] init];
	self.statusLabel.numberOfLines = 0;
	self.statusLabel.font = [UIFont monospacedSystemFontOfSize:16 weight:UIFontWeightRegular];

	self.virtualLabel = [[UILabel alloc] init];
	self.virtualLabel.numberOfLines = 0;
	self.virtualLabel.font = [UIFont monospacedSystemFontOfSize:15 weight:UIFontWeightRegular];

	self.touchCanvas = [[UIView alloc] init];
	self.touchCanvas.backgroundColor = UIColor.secondarySystemBackgroundColor;
	self.touchCanvas.layer.cornerRadius = 18;

	self.moveDot = [self makeDot:[UIColor systemBlueColor]];
	self.aimDot = [self makeDot:[UIColor systemOrangeColor]];
	[self.touchCanvas addSubview:self.moveDot];
	[self.touchCanvas addSubview:self.aimDot];

	UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[
		self.statusLabel,
		self.touchCanvas,
		self.virtualLabel
	]];
	stack.axis = UILayoutConstraintAxisVertical;
	stack.spacing = 18;
	stack.translatesAutoresizingMaskIntoConstraints = NO;
	self.touchCanvas.translatesAutoresizingMaskIntoConstraints = NO;
	[self.view addSubview:stack];

	[NSLayoutConstraint activateConstraints:@[
		[stack.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:20],
		[stack.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-20],
		[stack.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:20],
		[self.touchCanvas.heightAnchor constraintEqualToConstant:330]
	]];

	__weak typeof(self) weakSelf = self;
	self.input.onUpdate = ^{
		__strong typeof(weakSelf) self = weakSelf;
		if (!self) return;
		[self.engine updateFromInput:self.input];
		[self refreshUI];
	};

	[NSTimer scheduledTimerWithTimeInterval:(1.0/60.0) repeats:YES block:^(NSTimer * _Nonnull timer) {
		__strong typeof(weakSelf) self = weakSelf;
		if (!self) return;
		[self.engine updateFromInput:self.input];
		[self refreshUI];
	}];

	[self refreshUI];
}

- (UIView *)makeDot:(UIColor *)color {
	UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
	v.backgroundColor = color;
	v.layer.cornerRadius = 22;
	return v;
}

- (BOOL)zh {
	return [[[NSLocale preferredLanguages] firstObject] hasPrefix:@"zh"];
}

- (void)refreshUI {
	BOOL zh = [self zh];
	self.statusLabel.text = [NSString stringWithFormat:
		zh ? @"鼠标：%@\n键盘：%@\n按住：%@\n鼠标 Δ：%.2f / %.2f" :
			 @"Mouse: %@\nKeyboard: %@\nHeld: %@\nMouse Δ: %.2f / %.2f",
		self.input.mouseConnected ? (zh ? @"已连接" : @"Connected") : (zh ? @"未连接" : @"Disconnected"),
		self.input.keyboardConnected ? (zh ? @"已连接" : @"Connected") : (zh ? @"未连接" : @"Disconnected"),
		[self.input.pressedKeys componentsJoinedByString:@" "],
		self.input.mouseDX,
		self.input.mouseDY
	];

	self.virtualLabel.text = [NSString stringWithFormat:
		zh ? @"虚拟源（本软件测试模型）\nMoveTouch: %.2f / %.2f %@\nAimTouch: %.2f / %.2f %@\nLeftStick: %.2f / %.2f\nRightStick: %.2f / %.2f" :
			 @"Virtual source (in-app test model)\nMoveTouch: %.2f / %.2f %@\nAimTouch: %.2f / %.2f %@\nLeftStick: %.2f / %.2f\nRightStick: %.2f / %.2f",
		self.engine.moveTouch.x, self.engine.moveTouch.y, self.engine.moveTouchDown ? @"●" : @"○",
		self.engine.aimTouch.x, self.engine.aimTouch.y, self.engine.aimTouchDown ? @"●" : @"○",
		self.engine.leftStickX, self.engine.leftStickY,
		self.engine.rightStickX, self.engine.rightStickY
	];

	CGSize s = self.touchCanvas.bounds.size;
	self.moveDot.center = CGPointMake(s.width * self.engine.moveTouch.x, s.height * self.engine.moveTouch.y);
	self.aimDot.center = CGPointMake(s.width * self.engine.aimTouch.x, s.height * self.engine.aimTouch.y);
	self.moveDot.alpha = self.engine.moveTouchDown ? 1.0 : 0.35;
	self.aimDot.alpha = self.engine.aimTouchDown ? 1.0 : 0.35;
}

@end

@implementation IBLogController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"log"];
	UIBarButtonItem *clear = [[UIBarButtonItem alloc] initWithTitle:[self zh] ? @"清空" : @"Clear"
															style:UIBarButtonItemStylePlain
														   target:self
														   action:@selector(clearTapped)];
	self.navigationItem.rightBarButtonItem = clear;

	__weak typeof(self) weakSelf = self;
	IBInputUpdateHandler previous = self.input.onUpdate;
	self.input.onUpdate = ^{
		if (previous) previous();
		[weakSelf.tableView reloadData];
	};
}

- (BOOL)zh {
	return [[[NSLocale preferredLanguages] firstObject] hasPrefix:@"zh"];
}

- (void)clearTapped {
	[self.input clearLog];
	[self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return MIN(self.input.eventLog.count, 150);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"log" forIndexPath:indexPath];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
	cell.textLabel.text = self.input.eventLog[indexPath.row];
	return cell;
}

@end
