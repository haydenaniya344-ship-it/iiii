#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^IBInputUpdateHandler)(void);

@interface IBInputHub : NSObject
@property (nonatomic, assign, readonly) BOOL keyboardConnected;
@property (nonatomic, assign, readonly) BOOL mouseConnected;
@property (nonatomic, assign, readonly) double mouseDX;
@property (nonatomic, assign, readonly) double mouseDY;
@property (nonatomic, assign, readonly) BOOL leftDown;
@property (nonatomic, assign, readonly) BOOL rightDown;
@property (nonatomic, copy, readonly) NSArray<NSString *> *pressedKeys;
@property (nonatomic, copy, readonly) NSArray<NSString *> *eventLog;
@property (nonatomic, copy, nullable) IBInputUpdateHandler onUpdate;

- (BOOL)isKeyDown:(NSString *)key;
- (void)clearLog;
@end

NS_ASSUME_NONNULL_END
