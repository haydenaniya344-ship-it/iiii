#import "IBHardwareController.h"

@implementation IBHardwareController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.title = [self zh] ? @"设备" : @"Hardware";
	[self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"cell"];
}

- (BOOL)zh {
	return [[[NSLocale preferredLanguages] firstObject] hasPrefix:@"zh"];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 1; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return 3; }

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return [self zh] ? @"你的硬件档案" : @"Your hardware profile";
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.textLabel.numberOfLines = 0;

	switch (indexPath.row) {
		case 0:
			cell.textLabel.text = @"Mouse / 鼠标\nLogitech G502 HERO";
			break;
		case 1:
			cell.textLabel.text = @"Keyboard / 键盘\nAULA K103";
			break;
		default:
			cell.textLabel.text = @"USB-C Hub / 集线器\nNIMASO NHB21E233";
			break;
	}
	return cell;
}
@end
