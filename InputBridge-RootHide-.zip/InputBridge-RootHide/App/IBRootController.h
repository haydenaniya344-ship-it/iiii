#import <UIKit/UIKit.h>

@interface IBRootController : UITabBarController
@end
