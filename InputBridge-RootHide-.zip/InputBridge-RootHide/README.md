# InputBridge — RootHide / Theos Edition

这是给你当前环境准备的版本：

- M2 iPad Pro
- iPadOS 16.5
- Relaxin / RootHide
- Sileo
- Logitech G502 HERO
- AULA K103
- NIMASO NHB21E233（硬件档案记录）

## 这一版是什么

这是一个真正的 Theos / RootHide 软件包工程，不依赖 Swift Playgrounds。

它包含：

1. `InputBridge.app`
   - 读取物理键盘
   - 读取物理鼠标
   - 实时事件日志
   - 中英双语
   - 软件层虚拟触控状态机
   - 软件层虚拟手柄状态机
   - WASD / 鼠标的虚拟源可视化
   - 设备档案

2. `inputbridged`
   - RootHide bootstrap 内的独立辅助进程
   - 当前只用于验证“App + 系统服务”两层架构
   - 不向其他 App 注入输入

## 重要边界

目前虚拟输入源用于 InputBridge 自己的研究/测试环境。

此工程**不会**：
- 修改鼠标/键盘的 USB VID/PID
- 隐藏真实 HID 设备
- 修改其他 App 的检测结果
- 向其他 App 注入触控
- 实现反作弊规避

这让你可以先把真正的 HID 捕获、标准化、虚拟设备状态机和 RootHide 软件结构做好。

---

# 你没有 Mac：最方便的构建方法

项目已经放了 `.github/workflows/build.yml`。

因此可以用 **GitHub Actions** 云端编译 `.deb`，不要求你的 iPad 升级，也不要求你本机有 Xcode。

大致流程：

1. 在 GitHub 新建一个私人仓库。
2. 把这个项目文件夹里的全部文件上传到仓库根目录。
3. 打开仓库的 `Actions`。
4. 选择 `Build RootHide DEB`。
5. 点 `Run workflow`。
6. 等构建完成。
7. 下载名为 `InputBridge-RootHide` 的 Artifact。
8. 解压得到 `.deb`。
9. 把 `.deb` 传到 iPad。
10. 用 Sileo / Filza 的 dpkg 安装。
11. Respring 或重启用户空间后，桌面出现 InputBridge。

## RootHide 构建方式

工程使用：

`THEOS_PACKAGE_SCHEME = roothide`

RootHide 官方开发文档要求 RootHide 包使用 roothide Theos / package scheme；本工程按这个结构准备。

## 目录结构

```text
InputBridge-RootHide/
├── App/                 iPad App
├── Daemon/              独立辅助进程
├── Resources/           App Info.plist
├── layout/              LaunchDaemon
├── entitlements.plist
├── control
├── Makefile
└── .github/workflows/   云端构建
```

## 当前测试逻辑

```text
G502 HERO + AULA K103
          ↓
      USB-C Hub
          ↓
       M2 iPad
          ↓
      IBInputHub
          ↓
   标准化输入状态
          ↓
    IBVirtualEngine
       ↙       ↘
 Virtual Touch  Virtual Gamepad
       ↓
 InputBridge 测试界面
```
