# RootHide notes

The project is configured with `THEOS_PACKAGE_SCHEME=roothide`.

The RootHide developer documentation states that:
- RootHide packages should be built with the RootHide Theos package scheme.
- RootHide uses a randomized jbroot instead of the fixed `/var/jb`.
- Executable apps that need RootHide access can use the RootHide entitlement set.

This project currently avoids hard-coded jailbreak filesystem paths so it does not need direct `jbroot()` calls.
